# OCR benchmark report

Best model is pending: complete valid coverage is not available for every requested model. The common-successful tables compare identical images; other tables are diagnostic, not a fair ranking.

VISPR supplies image-level labels only. Missing labels are image-attribute occurrences, not physical regions. Extra labels are unannotated predictions, not confirmed false positives. IoU, reference redaction coverage, CER, WER and ROUGE-L are unavailable until independently verified region/transcript annotations are supplied. OCR scores measure native OCR plus the fixed English text rules. Review images for unlocalized predictions and excess masking. This is a curated training-split diagnostic cohort, not a held-out generalization test. The cohort differs from the old sample by 11 images.

## Coverage

- florence2: 0/50 valid, 2 failed, 48 not attempted.
- chandra: 0/50 valid, 0 failed, 50 not attempted.
- dots_ocr: 0/50 valid, 0 failed, 50 not attempted.

See CSV/JSON tables for full and text-only scopes, per-category errors and runtime. See report.html for image artifacts.

Historical timing comparison: Historical detection-call timings only. Cohort differs by 11 images; hardware and protocols may differ. These are context, not paired speedup claims. See runtime.csv for current and previous detection-call medians.

## Next steps

- Inspect missed attributes and unlocalized detections before selecting a model.
- Label a separate set of reference boxes and transcripts before assessing localization, redaction coverage or OCR text accuracy.
- Review pilot GPU placement, generation calls and stage timings before changing precision, resolution or token limits.
